int subtract(int a, int b);
