#include<stdio.h>
#include <stdlib.h>
#include "subtract.h"

int subtract(int a, int b){
  return a-b;
}
