#include<stdio.h>
#include <stdlib.h>
#include "add.h"

int add(int a, int b){
  return a+b;
}
